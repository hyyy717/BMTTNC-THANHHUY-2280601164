﻿using Bai3.Models;
using Microsoft.AspNetCore.Mvc;

public class StudentController : Controller
{
    private static List<Student> students = new List<Student>();

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult ShowKQ(string mssv, string hoTen, float diemTB, string chuyenNganh)
    {
        // Lưu thông tin sinh viên
        var student = new Student
        {
            MSSV = mssv,
            HoTen = hoTen,
            DiemTB = diemTB,
            ChuyenNganh = chuyenNganh
        };
        students.Add(student);

        // Đếm số lượng sinh viên cùng chuyên ngành
        int count = students.Count(s => s.ChuyenNganh == chuyenNganh);

        // Truyền dữ liệu sang view
        ViewBag.MSSV = mssv;
        ViewBag.HoTen = hoTen;
        ViewBag.DiemTB = diemTB;
        ViewBag.ChuyenNganh = chuyenNganh;
        ViewBag.Count = count;
        ViewBag.Students = students;

        return View();
    }

    public IActionResult Search()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Search(string mssv)
    {
        var student = students.FirstOrDefault(s => s.MSSV == mssv);
        ViewBag.Student = student;
        ViewBag.SearchMSSV = mssv;
        return View();
    }

    public IActionResult ChangeMajor(string mssv)
    {
        var student = students.FirstOrDefault(s => s.MSSV == mssv);
        if (student == null)
        {
            return RedirectToAction("Index");
        }
        ViewBag.MSSV = mssv;
        ViewBag.HoTen = student.HoTen;
        ViewBag.DiemTB = student.DiemTB;
        ViewBag.ChuyenNganh = student.ChuyenNganh;
        return View();
    }

    [HttpPost]
    public IActionResult ChangeMajor(string mssv, string chuyenNganh)
    {
        var student = students.FirstOrDefault(s => s.MSSV == mssv);
        if (student != null)
        {
            student.ChuyenNganh = chuyenNganh; // Cập nhật chuyên ngành
        }

        // Đếm lại số lượng sinh viên cùng chuyên ngành
        int count = students.Count(s => s.ChuyenNganh == chuyenNganh);

        // Truyền dữ liệu sang view ShowKQ
        ViewBag.MSSV = mssv;
        ViewBag.HoTen = student.HoTen;
        ViewBag.DiemTB = student.DiemTB;
        ViewBag.ChuyenNganh = chuyenNganh;
        ViewBag.Count = count;
        ViewBag.Students = students;

        return View("ShowKQ");
    }
}