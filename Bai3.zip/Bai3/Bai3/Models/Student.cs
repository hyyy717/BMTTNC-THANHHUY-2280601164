﻿namespace Bai3.Models
{
    public class Student
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public float DiemTB { get; set; }
        public string ChuyenNganh { get; set; }
    }
}
